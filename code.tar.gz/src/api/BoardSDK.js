import mondaySdk from 'monday-sdk-js';
const monday = mondaySdk();

class BoardBase {
  constructor(boardId) {
    this.boardId = boardId;
  }

  aggregate() {
    // Variables to store the requested query operations
    let groupByKey = null;
    let countKey = 'count';
    let whereFilters = null;

    const builder = {
      groupBy: function(field) { groupByKey = field; return builder; },
      countItems: function(field) { countKey = field; return builder; },
      where: function(conditions) { whereFilters = conditions; return builder; },
      
      execute: async () => {
        try {
          // 1. Fetch the raw items from Monday (adding 'type' to help find status columns)
          const query = `query { boards (ids: [${this.boardId}]) { items_page(limit: 500) { items { name column_values { id type text } } } } }`;
          const response = await monday.api(query, { apiVersion: '2024-01' });
          
          const items = response?.data?.boards?.[0]?.items_page?.items || [];

          // 2. Flatten the Monday columns into a simple object
          const parsedItems = items.map(item => {
            const row = { name: item.name };
            
            // Find the main status column to map to your hook's custom keys
            const statusCol = item.column_values.find(c => c.type === 'color' || c.id.includes('status'));
            
            // Ensure the specific keys your hook looks for exist in the row
            if (statusCol) {
               row['status'] = statusCol.text || 'Blank';
               row['workStatus'] = statusCol.text || 'Blank';
               row['deliveryStatus'] = statusCol.text || 'Blank';
            }
            return row;
          });

          let filteredItems = parsedItems;

          // 3. Apply the .where() filters (e.g., status: ["BLOCKED", "OVERDUE"])
          if (whereFilters) {
            filteredItems = filteredItems.filter(item => {
              return Object.entries(whereFilters).every(([key, validValues]) => {
                const itemValue = item[key];
                if (Array.isArray(validValues)) return validValues.includes(itemValue);
                return validValues === itemValue;
              });
            });
          }

          // 4. Apply the .groupBy() logic (Returns an array so v.filter WILL work)
          if (groupByKey) {
            const groups = {};
            filteredItems.forEach(item => {
              const val = item[groupByKey] || "Unknown";
              groups[val] = (groups[val] || 0) + 1;
            });

            return Object.entries(groups).map(([key, count]) => ({
              [groupByKey]: key,
              [countKey]: count
            }));
          } 
          
          // 5. If no grouping, just return the total count inside an array
          return [{ [countKey]: filteredItems.length }];

        } catch (err) {
          console.error(`Error fetching board ${this.boardId}:`, err);
          return []; // Always return an array to prevent crashes
        }
      }
    };
    
    return builder;
  }
}

// Your existing specific board exports
export class ActionRegisterMcsoBoard extends BoardBase { constructor() { super('8055409759'); } }
export class SsrsReportsStatusTrackerMcsoBoard extends BoardBase { constructor() { super('9161263758'); } }
export class RfiRequestForInformationMcsoBoard extends BoardBase { constructor() { super('8055796270'); } }
export class SubSubmittalLogMcsoBoard extends BoardBase { constructor() { super('8055800458'); } }
export class InterfaceStatusTrackerMcsoBoard extends BoardBase { constructor() { super('9043836950'); } }