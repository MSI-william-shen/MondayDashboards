import { useState, useEffect, useCallback } from 'react';
import { 
  ActionRegisterMcsoBoard, 
  SsrsReportsStatusTrackerMcsoBoard, 
  RfiRequestForInformationMcsoBoard, 
  SubSubmittalLogMcsoBoard, 
  InterfaceStatusTrackerMcsoBoard 
} from '@api/BoardSDK.js';

export const useExecutiveData = () => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchBoardData = useCallback(async () => {
    setLoading(true);
    try {
      const sdk = {
        action: new ActionRegisterMcsoBoard(),
        ssrs: new SsrsReportsStatusTrackerMcsoBoard(),
        rfi: new RfiRequestForInformationMcsoBoard(),
        sub: new SubSubmittalLogMcsoBoard(),
        interface: new InterfaceStatusTrackerMcsoBoard()
      };

      // Aggregations - Get all statuses
      const [actionResRaw, rfiResRaw, subResRaw, interfaceResRaw, ssrsResRaw] = await Promise.all([
        sdk.action.aggregate().groupBy('status').countItems('count').execute(),
        sdk.rfi.aggregate().groupBy('workStatus').countItems('count').execute(),
        sdk.sub.aggregate().groupBy('workStatus').countItems('count').execute(),
        sdk.interface.aggregate().groupBy('deliveryStatus').countItems('count').execute(),
        sdk.ssrs.aggregate().groupBy('deliveryStatus').countItems('count').execute()
      ]);

      // Manual Filtering (since notAnyOf is unsupported in aggregate API)
      const actionRes = actionResRaw.filter(s => s.status !== 'CLOSED');
      const rfiRes = rfiResRaw.filter(s => s.workStatus !== 'CLOSED');
      const subRes = subResRaw.filter(s => s.workStatus !== 'CLOSED');
      const interfaceRes = interfaceResRaw.filter(s => s.deliveryStatus !== '✅ COMPLETE');
      const ssrsRes = ssrsResRaw.filter(s => s.deliveryStatus !== '✅ COMPLETE');

      // Critical Checks (Direct matching filters ARE supported)
      const [blockedActions, delinquentRFIs, delinquentSubs, blockedInterfaces, blockedSSRS] = await Promise.all([
        sdk.action.aggregate().where({ status: ['BLOCKED', 'OVERDUE MSI', 'OVERDUE MCSO'] }).countItems('count').execute(),
        sdk.rfi.aggregate().where({ workStatus: 'DELINQUENT' }).countItems('count').execute(),
        sdk.sub.aggregate().where({ workStatus: 'DELINQUENT' }).countItems('count').execute(),
        sdk.interface.aggregate().where({ deliveryStatus: '🛑 BLOCKED' }).countItems('count').execute(),
        sdk.ssrs.aggregate().where({ deliveryStatus: '🛑 BLOCKED' }).countItems('count').execute()
      ]);

      setData({
        boards: {
          action: { title: 'Action Register', stats: actionRes, atRisk: blockedActions[0]?.count || 0 },
          rfi: { title: 'RFIs', stats: rfiRes, atRisk: delinquentRFIs[0]?.count || 0 },
          sub: { title: 'Submittals', stats: subRes, atRisk: delinquentSubs[0]?.count || 0 },
          ssrs: { title: 'SSRS Reports', stats: ssrsRes, atRisk: blockedSSRS[0]?.count || 0 },
          interface: { title: 'Interfaces', stats: interfaceRes, atRisk: blockedInterfaces[0]?.count || 0 }
        },
        criticalTotal: (blockedActions[0]?.count || 0) + (delinquentRFIs[0]?.count || 0) + (delinquentSubs[0]?.count || 0) + (blockedInterfaces[0]?.count || 0) + (blockedSSRS[0]?.count || 0)
      });
    } catch (err) {
      console.error('Executive Data Fetch Error:', err);
      setError('Failed to aggregate board metrics.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchBoardData(); }, [fetchBoardData]);

  return { data, loading, error, refetch: fetchBoardData };
};
