import React from 'react';
import { SimpleGrid } from '@chakra-ui/react';
import ChartCard from '@components/ChartCard';
import { Pie, Bar } from '@components/Charts';

export const DashboardCharts = ({ boards, loading }) => {
  if (loading || !boards) return null;

  const transformData = (stats, labelKey) => 
    stats.map(s => ({ id: s[labelKey], label: s[labelKey], value: s.count }));

  return (
    <SimpleGrid columns={{ base: 1, lg: 2 }} gap={6}>
      <ChartCard title="Active Actions" subtitle="Workload distribution (excl. closed)">
        <Pie data={transformData(boards.action.stats, 'status')} showLegend colors={{ scheme: 'set2' }} />
      </ChartCard>

      <ChartCard title="Active Interfaces" subtitle="Integration pipeline (excl. complete)">
        <Bar 
          data={boards.interface.stats.map(s => ({ label: s.deliveryStatus, value: s.count }))} 
          xField="label" 
          yField="value" 
          colors={['#1b263b']}
          layout="horizontal"
        />
      </ChartCard>

      <ChartCard title="Active RFIs" subtitle="In-progress requests (excl. closed)">
        <Bar 
          data={boards.rfi.stats.map(s => ({ label: s.workStatus, value: s.count }))} 
          xField="label" 
          yField="value" 
          colors={['#9d50dd']}
        />
      </ChartCard>

      <ChartCard title="Active Submittals" subtitle="Review cycle status (excl. closed)">
        <Pie data={transformData(boards.sub.stats, 'workStatus')} showLegend colors={{ scheme: 'tableau10' }} />
      </ChartCard>

      <ChartCard title="Active SSRS Reports" subtitle="Development tracking (excl. complete)">
        <Bar 
          data={boards.ssrs.stats.map(s => ({ label: s.deliveryStatus, value: s.count }))} 
          xField="label" 
          yField="value" 
          colors={['#00c875']}
          layout="horizontal"
        />
      </ChartCard>
    </SimpleGrid>
  );
};
