import React from 'react';
import {
  PieChart,
  Pie as RechartsPie,
  Cell,
  BarChart,
  Bar as RechartsBar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Legend
} from 'recharts';
import { Box } from '@chakra-ui/react';

// A robust color palette for our Pie charts
const PIE_COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#df2f4a', '#00c875'];

export const Pie = ({ data, showLegend, colors }) => {
  // Ensure we don't crash if data is missing or empty
  if (!data || data.length === 0) return null;

  return (
    <Box w="full" h="full" minH="250px">
      <ResponsiveContainer width="100%" height="100%">
        <PieChart>
          <RechartsPie
            data={data}
            cx="50%"
            cy="50%"
            innerRadius={60}
            outerRadius={80}
            paddingAngle={5}
            dataKey="value"
            nameKey="label"
          >
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} />
            ))}
          </RechartsPie>
          <Tooltip 
            contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px rgba(0,0,0,0.1)' }} 
          />
          {showLegend && <Legend verticalAlign="bottom" height={36} />}
        </PieChart>
      </ResponsiveContainer>
    </Box>
  );
};

export const Bar = ({ data, xField = 'label', yField = 'value', colors = ['#3182ce'], layout = 'vertical' }) => {
  if (!data || data.length === 0) return null;

  // In Recharts, if you want horizontal bars (left-to-right), the layout prop must be 'vertical'.
  const isHorizontalBar = layout === 'horizontal';

  return (
    <Box w="full" h="full" minH="250px">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart
          data={data}
          layout={isHorizontalBar ? 'vertical' : 'horizontal'}
          margin={{ top: 10, right: 30, left: isHorizontalBar ? 20 : 0, bottom: 5 }}
        >
          {isHorizontalBar ? (
            <>
              {/* Horizontal Bar Config */}
              <XAxis type="number" hide />
              <YAxis 
                dataKey={xField} 
                type="category" 
                axisLine={false} 
                tickLine={false} 
                width={100}
                tick={{ fontSize: 12, fill: '#718096' }}
              />
            </>
          ) : (
            <>
              {/* Vertical Column Config */}
              <XAxis 
                dataKey={xField} 
                axisLine={false} 
                tickLine={false}
                tick={{ fontSize: 12, fill: '#718096' }}
              />
              <YAxis type="number" axisLine={false} tickLine={false} tick={{ fontSize: 12 }} />
            </>
          )}
          
          <Tooltip 
            cursor={{ fill: 'rgba(0,0,0,0.04)' }} 
            contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px rgba(0,0,0,0.1)' }}
          />
          
          <RechartsBar 
            dataKey={yField} 
            fill={colors[0] || '#3182ce'} 
            radius={isHorizontalBar ? [0, 4, 4, 0] : [4, 4, 0, 0]} 
            barSize={isHorizontalBar ? 24 : 40}
          />
        </BarChart>
      </ResponsiveContainer>
    </Box>
  );
};